const isValidateSAPhoneNumber = require('./index'); //Importing isValidateSAPhoneNumber from index.js

describe('Valid cellphone Checker Test Suite', () =>{
    let cellphoneNumbers = ['0847896823', '+27847896823', '0718307101', '+27718307101','0618307101', '+27618307101'];
    test('#1 Verify valid South African cellphone numbers', () =>{

        cellphoneNumbers.forEach((phoneNumber)=>{
            console.log('Testing valid South African cellphone number: ', phoneNumber);
            expect(isValidateSAPhoneNumber(phoneNumber)).toBe(true); //Checking if valdator returns true for valid cellphone number

        });
    });
});

describe('Invalid cellphone checker test suite', ()=>{
    let invalidcellphoneNumbers = ['0105297007', 'abc', '!@#%^%^&', '', '084123456789', 6];
    test('#2 Verify invalid South African cellphone numbers', ()=> {
        
        invalidcellphoneNumbers.forEach((phoneNumber)=>{
            console.log('Testing invalid South African cellphone number: ', phoneNumber);
            expect(isValidateSAPhoneNumber(phoneNumber)).toBe(false); //Checking if validator returns false for invaild cellphone number
        });
        
    });
});

