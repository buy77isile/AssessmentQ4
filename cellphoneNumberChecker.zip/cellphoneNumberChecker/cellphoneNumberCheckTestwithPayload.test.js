//cellphoneCheckTestwithPayload.test.js which import function from module which in index.js
const fs = require('fs/promises'); // Using promises for async file access
const isValidateSAPhoneNumber = require('./index'); //import statement
   
describe('isValidateSAPhoneNumbers', () => {
  let phoneNumbers;
 
  beforeAll(async () => {
    // Read phone numbers data asynchronously
    // This is approach is for separating the test data from the actual tests
    try {
      const data = await fs.readFile('./phone_numbers.json', 'utf8'); //Reading cellphone number file data
      phoneNumbers = JSON.parse(data);
    } catch (error) {
      console.log('Error reading phone numbers data:', error);
    }
  });
 
  // Test valid South African phone numbers
  test('Valid South African phone numbers', () => {
    phoneNumbers.valid.forEach((phoneNumber) => {
      try {
        console.log('Testing valid phone number:', phoneNumber);
        expect(isValidateSAPhoneNumber(phoneNumber)).toBe(true);
      } catch (error) {
        console.log('Error testing phone number:', phoneNumber, error); // Catching the error associated with cellphone number tested
      }
    });
  });
 
  // Test invalid South African phone numbers
  test('Invalid South African phone numbers', () => {
    phoneNumbers.invalid.forEach((phoneNumber) => {
      try {
        console.log('Testing invalid phone number:', phoneNumber);
        expect(isValidateSAPhoneNumber(phoneNumber)).toBe(false);
      } catch (error) {
        console.log('Error testing phone number:', phoneNumber, error); // Catching the error associated with cellphone number tested
      }
    });
  });
});